package com.example.rssrt;


import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;
public class MainActivity extends AppCompatActivity {

    private static String rss_url;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        rss_url = "http://www.broker-forex.fr/rss/forex.xml";
        setContentView(R.layout.activity_main);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        new LoaderTask().execute(rss_url);

        toolbar.setOnMenuItemClickListener(new Toolbar.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                if(item.getItemId() == R.id.action_settings){
                    Intent intent = new Intent(getApplicationContext(), SettingsActivity.class);
                    startActivityForResult(intent, 0);
                    return true;
                }
                return false;
            }
        });

        FloatingActionButton fab = findViewById(R.id.buton);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Chargement du flux en cours", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
                new LoaderTask().execute(rss_url);
            }
        });

        ListView lv = findViewById(R.id.news_list);
        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                RssLoader.RssItem selectedItem = (RssLoader.RssItem)parent.getItemAtPosition(position);
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(selectedItem.getLink()));
                startActivity(intent);
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        int id = item.getItemId();

        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    class LoaderTask extends AsyncTask<String, String, RssLoader.RssManager>{
        @Override
        protected RssLoader.RssManager doInBackground(String... urls){
            return RssLoader.parse((urls[0]));
        }

        @Override
        protected void onPostExecute(RssLoader.RssManager news){
            super.onPostExecute(news);
            RssItemAdapter adapter = new RssItemAdapter(MainActivity.this, news.getItems());
            ListView news_list = findViewById(R.id.news_list);
            TextView titleText = findViewById(R.id.title_text);
            TextView subTitleText = findViewById(R.id.subtitle_text);

            news_list.setAdapter(adapter);
            titleText.setText(news.getTitle());
            subTitleText.setText(news.getDescription());

            news_list.invalidateViews();
            titleText.invalidate();
            subTitleText.invalidate();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        // check that it is the SecondActivity with an OK result
        if (requestCode == 0) {
                // get String data from Intent
                String returnString = data.getStringExtra(Intent.EXTRA_TEXT);
                rss_url = returnString;
                new LoaderTask().execute(returnString);
            }
    }
}
