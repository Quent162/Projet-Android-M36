package com.example.rssrt;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

public class RssItemAdapter extends ArrayAdapter<RssLoader.RssItem> {

    public RssItemAdapter(Context context, List<RssLoader.RssItem> tweets) {
        super(context, 0, tweets);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        if(convertView == null){
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.row_item,parent, false);
        }

        RssItemViewHolder viewHolder = (RssItemViewHolder) convertView.getTag();
        if(viewHolder == null){
            viewHolder = new RssItemViewHolder();
            viewHolder.title = (TextView) convertView.findViewById(R.id.title);
            viewHolder.description = (TextView) convertView.findViewById(R.id.summary);
            convertView.setTag(viewHolder);
        }

        RssLoader.RssItem item = getItem(position);
        viewHolder.title.setText(item.getTitle());
        viewHolder.description.setText(item.getDescription());

        return convertView;
    }

    private class RssItemViewHolder{
        public TextView title;
        public TextView description;
    }
}