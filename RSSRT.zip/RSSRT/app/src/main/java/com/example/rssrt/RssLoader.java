package com.example.rssrt;

import android.util.Xml;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class RssLoader {

    private static final String ns = null;

    public static class RssManager
    {
        public String title;
        public String summary;
        public final ArrayList<RssItem> items;

        private RssManager()
        {
            items = new ArrayList<>();
        }

        public void addRssItem(RssItem item)
        {
            items.add(item);
        }

        public void setTitle(String title)
        {
            this.title = title;
        }

        public void setDescription(String description)
        {
            this.summary = description;
        }

        public String getTitle()
        {
            return this.title;
        }

        public String getDescription()
        {
            return this.summary;
        }

        public ArrayList<RssItem> getItems() { return this.items; }
    }

    public static class RssItem {

        public final String title;
        public final String link;
        public final String summary;

        private RssItem(String title, String summary, String link) {
            this.title = title;
            this.summary = summary;
            this.link = link;
        }

        public String getTitle()
        {
            return this.title;
        }

        public String getLink()
        {
            return this.link;
        }

        public String getDescription()
        {
            return this.summary;
        }
    }

    public static RssManager parse(String url){
        RssManager manager = new RssManager();
        XmlPullParser parser = Xml.newPullParser();
        try {
            InputStream stream = new URL(url).openConnection().getInputStream();
            parser.setInput(stream, null);
            String rssTitle = null;
            String rssDescription = null;

            String title = null;
            String summary = null;
            String link = null;

            int eventType = parser.getEventType();
            while (eventType != XmlPullParser.END_DOCUMENT) {
                if (eventType == XmlPullParser.START_TAG) {
                    String name = parser.getName();
                    if (name.equalsIgnoreCase("title")) {
                        if(rssTitle == null){
                            rssTitle = parser.nextText().trim();
                        }else{
                            title = parser.nextText().trim();
                        }
                    } else if (name.equalsIgnoreCase("link")) {
                        link = parser.nextText().trim();
                    } else if (name.equalsIgnoreCase("description")) {
                        if(rssDescription == null){
                            rssDescription = parser.nextText().trim();
                        }else{
                            summary = parser.nextText().trim();
                        }
                    }
                }

                if(title != null && !title.isEmpty() && link != null && !link.isEmpty() && summary != null && !summary.isEmpty()) {
                    manager.addRssItem(new RssItem(title, summary, link));
                    title = "";
                    link = "";
                    summary = "";
                }
                eventType = parser.next();
            }

            manager.setDescription(rssDescription);
            manager.setTitle(rssTitle);

        } catch (XmlPullParserException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return manager;
    }
}
